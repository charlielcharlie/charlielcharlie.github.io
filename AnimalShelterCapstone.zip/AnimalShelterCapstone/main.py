from Animal import Animal
from Database import Database

database = Database()


# Main function
def main():
    while True:

        # main menu
        print("1: Create new entry.")
        print("2: Read all files.")
        print("3: Read a file.")
        print("4: Update a file.")
        print("5: Delete a file.")
        print("6: Exit")

        try:
            option = int(input("Option: "))

            if option == 1:
                animal = Animal.user_input()
                database.insert(animal)

            elif option == 2:
                data = database.read_all()
                for animal in data:
                    print(animal)

            elif option == 3:
                animal_id = input("Enter the animal id: ")
                data = database.read_one(animal_id)
                if data is None:
                    print("Error")
                else:
                    print(data)

            elif option == 4:
                animal_id = input("Enter the animal id: ")
                animal_update = Animal.user_input()
                database.update(animal_id, animal_update)
                print("Successfully updated")

            elif option == 5:
                animal_id = input("Enter the animal id: ")
                database.delete(animal_id)
                print("Successfully deleted")

            elif option == 6:
                break
            else:
                print("Invalid")

        except Exception as e:
            print(e)
            print("Invalid")


# Runs the program
if __name__ == "__main__":
    main()
