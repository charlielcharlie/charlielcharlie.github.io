# Class to be imported into main
class Animal:
    def __init__(self, animal_id, name, outcome_type, age_upon_outcome, animal_type):
        self.animal_id = animal_id
        self.name = name
        self.outcome_type = outcome_type
        self.age_upon_outcome = age_upon_outcome
        self.animal_type = animal_type

    @classmethod
    def user_input(cls):
        animal_id = input("Enter Animal Id: ")
        name = input("Enter animal name: ")
        outcome_type = input("Enter outcome type: ")
        age_upon_outcome = int(input("Enter animal age: "))
        animal_type = input("Enter animal type: ")

        return cls(animal_id, name, outcome_type, age_upon_outcome, animal_type)
