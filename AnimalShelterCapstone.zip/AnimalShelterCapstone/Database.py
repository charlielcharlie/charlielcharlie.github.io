import pymongo


class Database:
    def __init__(self):
        # Connect to MongoDB Atlas
        try:
            client = pymongo.MongoClient("mongodb+srv://cr10780:shelteraacadmin@aac.4ax9a.mongodb.net/?retryWrites"
                                         "=true&w=majority&appName=aac")
            self.db = client['AAC']
            self.collection = self.db["animals"]
        except Exception as e:
            print(f"Error: {e}")

    # Create method
    def create(self, animal):
        try:
            data = {
                'animal_id': animal.animal_id,
                'name': animal.name,
                'outcome_type': animal.outcome_type,
                'age_upon_outcome': animal.age_upon_outcome,
                'animal_type': animal.animal_type
            }
            animal_id = self.collection.insert_one(data).inserted_id
            print(f"Data inserted with ID: {animal_id}")
        except Exception as e:
            print(f"Error: {e}")

    # Read method
    def read_one(self, animal_id):
        data = self.collection.find_one({'animal_id': animal_id})
        return data

    # Read all method
    def read_all(self):
        data = self.collection.find()
        return data

    # Update method with dictionary
    def update(self, animal_id, animal):
        data = {
            'name': animal.name,
            'outcome_type': animal.outcome_type,
            'age_upon_outcome': animal.age_upon_outcome,
            'animal_type': animal.animal_type
        }
        self.collection.update_one({'animal_id': animal_id}, {"$set": data})

    # Delete Method
    def delete(self, animal_id):
        self.collection.delete_one({'animal_id': animal_id})
